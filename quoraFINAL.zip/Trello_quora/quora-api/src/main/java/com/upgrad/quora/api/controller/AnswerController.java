package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.AnswerService;
import com.upgrad.quora.service.pojo.AnswerRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class AnswerController {

    @Autowired
    private AnswerService answerService;
    @RequestMapping(method = RequestMethod.POST, value = "/question/{questionId}/answer/create")
    public ApiResponse createAnswer(@RequestHeader("authorization") final String authorization,@PathVariable String questionId, @RequestBody @Valid AnswerRequestPojo answerRequestPojo){
        return answerService.createAnswer(authorization,answerRequestPojo, questionId);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/answer/edit/{answerId}")
    public ApiResponse editAnswerContent(@RequestHeader("authorization") final String authorization,@PathVariable String answerId, @RequestBody @Valid AnswerRequestPojo answerRequestPojo){
        return answerService.editAnswerContent(authorization,answerId, answerRequestPojo);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/answer/delete/{answerId}")
    public ApiResponse deleteAnswer(@RequestHeader("authorization") final String authorization,@PathVariable String answerId){
        return answerService.deleteAnswer(authorization,answerId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "answer/all/{questionId}")
    public ApiResponse getAllAnswersToQuestion(@RequestHeader("authorization") final String authorization,@PathVariable String questionId){
        return answerService.getAllAnswersToQuestion(authorization,questionId);
    }
}
