package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.QuestionService;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.pojo.QuestionRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;

@RestController
public class QuestionController {

    @Autowired
    QuestionService questionService;

    @RequestMapping(method = RequestMethod.POST, value ="/question/create")
    public ApiResponse createQuestion(@RequestHeader("authorization") final String authorization, @RequestBody @Valid QuestionRequestPojo questionRequestPojo)
        throws AuthorizationFailedException {
        return questionService.createQuestion(authorization, questionRequestPojo);
    }

    @RequestMapping(method = RequestMethod.GET, value ="/question/all")
    public ApiResponse getAllQuestions(@RequestHeader("authorization") final String authorization)
        throws AuthorizationFailedException {
        return questionService.getQuestions(authorization);
    }

    @RequestMapping(method = RequestMethod.PUT, value ="/question/edit/{questionId}")
    public ApiResponse editQuestionContent(@RequestHeader("authorization") final String authorization, @PathVariable String questionId, @RequestBody @Valid QuestionRequestPojo questionRequestPojo)
        throws AuthorizationFailedException {
        return questionService.editQuestionContent(authorization, questionId, questionRequestPojo);
    }


    @RequestMapping(method = RequestMethod.DELETE, value ="/question/delete/{questionId}")
    public ApiResponse deleteQuestion(@RequestHeader("authorization") final String authorization,@PathVariable String questionId)
        throws AuthorizationFailedException {
        return questionService.deleteQuestion(authorization,questionId);
    }

    @RequestMapping(method = RequestMethod.GET, value ="question/all/{userId}")
    public ApiResponse getAllQuestionsByUser(@RequestHeader("authorization") final String authorization,@PathVariable String userId){
        return questionService.getAllQuestionsByUser(authorization,userId);
    }


}
