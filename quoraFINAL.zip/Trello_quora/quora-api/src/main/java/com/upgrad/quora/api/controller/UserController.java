package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.UserService;
import com.upgrad.quora.service.exception.AuthenticationFailedException;
import com.upgrad.quora.service.exception.SignOutRestrictedException;
import com.upgrad.quora.service.pojo.SignupUserRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(method= RequestMethod.POST, value = "/user/signup")
    public ApiResponse signup(@RequestBody @Valid SignupUserRequestPojo signupUserRequestPojo){
        return userService.registerNewUser(signupUserRequestPojo);
    }

    @RequestMapping(method= RequestMethod.POST, value = "/user/signin")
    public ApiResponse signin(final String authorization) throws AuthenticationFailedException {
        byte[] decode = Base64.getDecoder().decode(authorization.split("Basic ")[1]);
        String decodedText = new String(decode);
        String[] decodedArray = decodedText.split(":");
        userService.signinUser(decodedArray[0],decodedArray[1]);
        return null;
    }

    @RequestMapping(method= RequestMethod.POST, value = "/user/signout")
    public ApiResponse signout(@RequestHeader("authorization") final String authorization) throws SignOutRestrictedException {
        return userService.signout(authorization);
    }




}
