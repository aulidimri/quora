package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.UserAuthTokenDao;
import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.SignupUserRequest;
import com.upgrad.quora.service.entity.UserAuthTokenEntity;
import com.upgrad.quora.service.exception.AuthenticationFailedException;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.SignOutRestrictedException;
import com.upgrad.quora.service.exception.SignUpRestrictedException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import com.upgrad.quora.service.pojo.SignupUserRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import java.time.ZonedDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private UserAuthTokenDao userAuthTokenDao;

    public ApiResponse registerNewUser(SignupUserRequestPojo signupUserRequestPojo) {
        SignupUserRequest signupUserRequest = null;
        try {
            SignupUserRequest users;
            String userName = signupUserRequestPojo.getUserName();
            String emailAddress = signupUserRequestPojo.getEmailAddress();
            String firstName = signupUserRequestPojo.getFirstName();
            String lastName = signupUserRequestPojo.getLastName();
            String password = PasswordCryptographyProvider.encrypt(signupUserRequestPojo.getPassword())[1];
            String country = signupUserRequestPojo.getCountry();
            String aboutMe = signupUserRequestPojo.getAboutMe();
            String dob = signupUserRequestPojo.getDob();
            String contactNumber = signupUserRequestPojo.getContactNumber();

            users = userDao.findByUserName(userName);
            if (users != null) {
                    throw new SignUpRestrictedException("SGR-001", "Try any other Username, this Username has already been taken");
            }
            users = userDao.findByEmailAddress(emailAddress);
            if (users != null) {
                throw new SignUpRestrictedException("SGR-002", "This user has already been registered, try with any other emailId");
            }
            signupUserRequest = new SignupUserRequest(firstName,lastName,userName,emailAddress,
                    password,country, aboutMe, dob,contactNumber);
            userDao.save(signupUserRequest);
            return new ApiResponse(HttpStatus.CREATED,"USER SUCCESSFULLY REGISTERED", signupUserRequest.getUuid());

        }
        catch(Exception e){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,"INTERNAL SERVER ERROR",signupUserRequest.getUuid());
        }
    }

    public SignupUserRequest signinUser(final String username, final String password)
        throws AuthenticationFailedException {
        SignupUserRequest userRequest = userDao.findByEmailAddress(username);
        if(userRequest == null){
            throw new AuthenticationFailedException("ATH-001", "This username does not exist");
        }
        final String encryptedPassword = PasswordCryptographyProvider.encrypt(password, userRequest.getSalt());
        if(encryptedPassword.equals(userRequest.getPassword())){
            JwtTokenProvider jwtTokenProvider = new JwtTokenProvider(encryptedPassword);
            UserAuthTokenEntity userAuthToken = new UserAuthTokenEntity();
            userAuthToken.setUser(userRequest);

            final ZonedDateTime now = ZonedDateTime.now();
            final ZonedDateTime expiresAt = now.plusHours(8);
            userAuthToken.setAccessToken(jwtTokenProvider.generateToken(userRequest.getUuid(), now, expiresAt));

            userAuthToken.setLoginAt(now);
            userAuthToken.setExpiresAt(expiresAt);
            userAuthToken.setLoginAt(now);

            return userRequest;
        }
        else{
            throw new AuthenticationFailedException("ATH-002", "Password Failed");
        }
    }

    public ApiResponse getUserProfile(String authorization, String userId) {
        try {
            UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
            if(userAuthTokenEntity == null){
                throw new AuthorizationFailedException("ATHR-001","User has not signed in");
            }
            if(userAuthTokenEntity.getLogoutAt() != null){
                throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
            }
            SignupUserRequest signupUserRequest = userDao.findByUuid(userId);
            if (signupUserRequest == null) {
                throw new UserNotFoundException("USR-001", "User with entered uuid does not exist");
            }
            else{
                Map<String, String> map = new HashMap<>();
                map.put("first_name", signupUserRequest.getFirstName());
                map.put("last_name",signupUserRequest.getLastName());
                map.put("user_name",signupUserRequest.getUserName());
                map.put("email_address",signupUserRequest.getEmailAddress());
                map.put("country",signupUserRequest.getCountry());
                map.put("aboutMe",signupUserRequest.getAboutMe());
                map.put("dob",signupUserRequest.getDob());
                map.put("contact_number",signupUserRequest.getContact_number());
                return new ApiResponse(HttpStatus.OK,"", map);
            }
        } catch (Exception ex) {
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,"INTERNAL_SERVER_ERROR", "");
        }

    }

    public ApiResponse signout(String authorization) throws SignOutRestrictedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new SignOutRestrictedException("SGR-001","User is not Signed in");
        }
        userAuthTokenEntity.setLogoutAt(ZonedDateTime.now());
        return new ApiResponse(HttpStatus.OK,"200","SIGNED OUT SUCCESSFULLY");
    }
}
