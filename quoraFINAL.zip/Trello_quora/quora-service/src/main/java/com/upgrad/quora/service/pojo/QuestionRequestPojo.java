package com.upgrad.quora.service.pojo;

public class QuestionRequestPojo {
    private String uuid;
    private String question;
    private String userId;

    public QuestionRequestPojo(String question, String userId) {
        this.question = question;
        this.userId = userId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
