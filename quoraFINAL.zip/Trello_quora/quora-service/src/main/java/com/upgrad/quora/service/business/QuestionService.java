package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.QuestionDao;
import com.upgrad.quora.service.dao.UserAuthTokenDao;
import com.upgrad.quora.service.entity.QuestionRequest;
import com.upgrad.quora.service.entity.UserAuthTokenEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import com.upgrad.quora.service.pojo.QuestionRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

    @Autowired
    private QuestionDao questionDao;

    @Autowired
    private UserAuthTokenDao userAuthTokenDao;

    public ApiResponse createQuestion(String authorization, QuestionRequestPojo questionRequestPojo)
        throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }
        String question = questionRequestPojo.getQuestion();
        String userId = questionRequestPojo.getUserId();
        QuestionRequest questionRequest = new QuestionRequest(question, userId);
        questionDao.save(questionRequest);
        return new ApiResponse(HttpStatus.CREATED,"Question created successfully",questionRequest.getUuid());
    }

    public ApiResponse getQuestions(String authorization) throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }
        List<QuestionRequest> questions = questionDao.findAll();
        return new ApiResponse(HttpStatus.OK,"Questions fetched successfully",questions);
    }

    public ApiResponse editQuestionContent(String authorization, String questionId, QuestionRequestPojo questionRequestPojo)
        throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }
        if(userAuthTokenEntity.getUser().getUuid() != questionRequestPojo.getUserId()){
            throw new AuthorizationFailedException("ATHR-003","Only the question owner can edit the question");
        }
        String uuid = questionRequestPojo.getUuid();
        QuestionRequest questionRequest = questionDao.findByUuid(uuid);
        try {
            if (questionRequest == null) {
                throw new InvalidQuestionException("QUES-001","Entered question uuid does not exist");
            }
            else{
                questionRequest.setQuestion(questionRequestPojo.getQuestion());
                questionDao.save(questionRequest);
                return new ApiResponse(HttpStatus.OK, "Questions changed successfully",questionRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",questionRequest.getUuid());

        }
    }

    public ApiResponse deleteQuestion(String authorization, String questionId)
        throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }
        QuestionRequest questionRequest = questionDao.findByUuid(questionId);
        try {
            if (questionRequest == null) {
                throw new InvalidQuestionException("QUES-001","Entered question uuid does not exist");
            }
            else if(userAuthTokenEntity.getUser().getUuid() != questionRequest.getUserId()){
                throw new AuthorizationFailedException("ATHR-003","Only the question owner can edit the question");
            }
            else{
                questionRequest.setDeleted(true);
                questionDao.save(questionRequest);
                return new ApiResponse(HttpStatus.OK, "Questions deleted successfully",questionRequest.getUuid());
            }
        }

        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",questionRequest.getUuid());

        }
    }

    public ApiResponse getAllQuestionsByUser(String authorization, String userId){
        try {
            UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
            if(userAuthTokenEntity == null){
                throw new AuthorizationFailedException("ATHR-001","User has not signed in");
            }
            if(userAuthTokenEntity.getLogoutAt() != null){
                throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
            }
            List<QuestionRequest> questionRequests = questionDao.findByUserId(userId);
            if (questionRequests.isEmpty()) {
                throw new UserNotFoundException("USR-001", "User with entered uuid whose question details are to be seen does not exist");
            } else {
                return new ApiResponse(HttpStatus.OK, "Fetched the questions successfully", questionRequests);
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR","");
        }
    }
}
