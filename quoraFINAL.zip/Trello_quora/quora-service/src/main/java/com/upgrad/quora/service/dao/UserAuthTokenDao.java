package com.upgrad.quora.service.dao;


import com.upgrad.quora.service.entity.UserAuthTokenEntity;
import org.springframework.data.repository.CrudRepository;

public interface UserAuthTokenDao extends CrudRepository<UserAuthTokenEntity, Long> {
  public UserAuthTokenEntity findByAccessToken(String accessToken);
}
