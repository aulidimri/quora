package com.upgrad.quora.service.dao;

import com.upgrad.quora.service.entity.AnswerRequest;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface AnswerDao extends CrudRepository<AnswerRequest, Long> {

    List<AnswerRequest> findAll();
    AnswerRequest findByUuid(String uuid);
    List<AnswerRequest> findByUserId(String userId);
    List<AnswerRequest> findByQuestionId(String questionId);

}
