package com.upgrad.quora.service.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

@Entity
public class SignupUserRequest {

    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "uuid", columnDefinition = "BINARY(16)")
    String uuid;
    @Column
    String firstName;
    @Column
    String lastName;
    @Column
    String userName;
    @Column
    String emailAddress;
    @Column
    String password;
    @Column
    String country;
    @Column
    String aboutMe;
    @Column
    String dob;
    @Column
    String contact_number;
    @Column
    String salt;
    @Column
    Boolean isDeleted;

    public SignupUserRequest(String firstName, String lastName, String userName, String emailAddress, String password, String country, String aboutMe, String dob, String contact_number, String salt) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.emailAddress = emailAddress;
        this.password = password;
        this.country = country;
        this.aboutMe = aboutMe;
        this.dob = dob;
        this.contact_number = contact_number;
        this.isDeleted = false;
        this.salt = salt;
    }

    public SignupUserRequest(String firstName, String lastName, String userName, String emailAddress, String password, String country, String aboutMe, String dob,
        String contactNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.emailAddress = emailAddress;
        this.password = password;
        this.country = country;
        this.aboutMe = aboutMe;
        this.dob = dob;
        this.contact_number = contact_number;
        this.isDeleted = false;
    }

    public Boolean getDeleted() {
        return isDeleted;
    }

    public void setDeleted(Boolean deleted) {
        isDeleted = deleted;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getContact_number() {
        return contact_number;
    }

    public void setContact_number(String contact_number) {
        this.contact_number = contact_number;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }
}
