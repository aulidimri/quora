package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.AnswerDao;
import com.upgrad.quora.service.dao.QuestionDao;
import com.upgrad.quora.service.dao.UserAuthTokenDao;
import com.upgrad.quora.service.entity.AnswerRequest;
import com.upgrad.quora.service.entity.QuestionRequest;
import com.upgrad.quora.service.entity.UserAuthTokenEntity;
import com.upgrad.quora.service.exception.AnswerNotFoundException;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import com.upgrad.quora.service.pojo.AnswerRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerService {

    @Autowired
    private AnswerDao answerDao;

    @Autowired
    private QuestionDao questionDao;
    @Autowired
    private UserAuthTokenDao userAuthTokenDao;

    public ApiResponse createAnswer(String authorization, AnswerRequestPojo answerRequestPojo, String questionId)
        throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }

        QuestionRequest questionRequest = questionDao.findByUuid(questionId);
        try {
            if (questionRequest == null) {
                throw new InvalidQuestionException("QUES-001", "The question entered is invalid");
            }

            else{
                String answer = answerRequestPojo.getAnswer();
                String userId = answerRequestPojo.getUserId();
                AnswerRequest answerRequest = new AnswerRequest(answer, userId,questionId);
                answerDao.save(answerRequest);
                return new ApiResponse(HttpStatus.CREATED,"Answer created successfully",answerRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,"INTERNAL_SERVER_ERROR","");
        }
    }

    public ApiResponse editAnswerContent(String authorization,String answerId, AnswerRequestPojo answerRequestPojo)
        throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }
        AnswerRequest answerRequest = answerDao.findByUuid(answerId);
        try {
            if (answerRequest == null) {
                throw new AnswerNotFoundException("ANS-001","Entered answer uuid does not exist");
            }
            else if(userAuthTokenEntity.getUser().getUuid() != answerRequestPojo.getUserId()){
                throw new AuthorizationFailedException("ATHR-003","Only the answer owner can edit the answer");
            }
            else{
                answerRequest.setAnswer(answerRequestPojo.getAnswer());
                answerDao.save(answerRequest);
                return new ApiResponse(HttpStatus.OK, "Answer changed successfully",answerRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",answerRequest.getUuid());

        }
    }

    public ApiResponse deleteAnswer(String authorization,String questionId)
        throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }
        AnswerRequest answerRequest = answerDao.findByUuid(questionId);
        try {
            if (answerRequest == null) {
                throw new InvalidQuestionException("ANS-001","Entered answer uuid does not exist'");
            }
            else if(userAuthTokenEntity.getUser().getUuid() != answerRequest.getUserId()){
                throw new AuthorizationFailedException("ATHR-003","Only the answer owner can delete the answer");
            }
            else{
                answerRequest.setDeleted(true);
                answerDao.save(answerRequest);
                return new ApiResponse(HttpStatus.OK, "Answer deleted successfully",answerRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",answerRequest.getUuid());

        }
    }

    public ApiResponse getAllAnswersToQuestion(String authorization,String questionId)
        throws AuthorizationFailedException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out.Sign in first to get user details");
        }
        try {
            List<AnswerRequest> answerRequests = answerDao.findByQuestionId(questionId);
            if (answerRequests.isEmpty()) {
                throw new UserNotFoundException("QUES-001", "The question with entered uuid whose details are to be seen does not exist");
            } else {
                return new ApiResponse(HttpStatus.OK, "Fetched the answers successfully", answerRequests);
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR","");
        }
    }
}
