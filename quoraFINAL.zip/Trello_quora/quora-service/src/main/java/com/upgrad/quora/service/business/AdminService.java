package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.UserAuthTokenDao;
import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.SignupUserRequest;
import com.upgrad.quora.service.entity.UserAuthTokenEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private UserAuthTokenDao userAuthTokenDao;

    public ApiResponse deleteUser(String authorization, String userId)
        throws AuthorizationFailedException, UserNotFoundException {
        UserAuthTokenEntity userAuthTokenEntity = userAuthTokenDao.findByAccessToken(authorization);
        if(userAuthTokenEntity == null){
            throw new AuthorizationFailedException("ATHR-001","User has not signed in");
        }
        if(userAuthTokenEntity.getLogoutAt() != null){
            throw new AuthorizationFailedException("ATHR-002","User is signed out");
        }
        SignupUserRequest signupUserRequest = userDao.findByUuid(userId);
        if(signupUserRequest == null){
            throw new UserNotFoundException("USR-001", "User with entered uuid to be deleted does not exist");
        }
        signupUserRequest.setDeleted(true);
        userDao.save(signupUserRequest);
        return new ApiResponse(HttpStatus.OK, "USER SUCCESSFULLY DELETED",signupUserRequest.getUuid());
    }
}
