package com.upgrad.quora.service.dao;

import com.upgrad.quora.service.entity.SignupUserRequest;
import org.springframework.data.repository.CrudRepository;

public interface UserDao extends CrudRepository<SignupUserRequest, Long> {

    SignupUserRequest findByUserName(String userName);
    SignupUserRequest findByEmailAddress(String emailAddress);
    SignupUserRequest findByUuid(String uuid);
}
