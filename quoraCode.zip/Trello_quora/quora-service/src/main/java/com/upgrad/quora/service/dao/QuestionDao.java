package com.upgrad.quora.service.dao;

import com.upgrad.quora.service.entity.QuestionRequest;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface QuestionDao extends CrudRepository<QuestionRequest, Long> {

    List<QuestionRequest> findAll();
    QuestionRequest findByUuid(String uuid);
    List<QuestionRequest> findByUserId(String userId);

}
