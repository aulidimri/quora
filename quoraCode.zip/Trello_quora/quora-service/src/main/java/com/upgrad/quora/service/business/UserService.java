package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.SignupUserRequest;
import com.upgrad.quora.service.exception.SignUpRestrictedException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import com.upgrad.quora.service.pojo.SignupUserRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    public ApiResponse registerNewUser(SignupUserRequestPojo signupUserRequestPojo) {
        SignupUserRequest signupUserRequest = null;
        try {
            SignupUserRequest users;
            String userName = signupUserRequestPojo.getUserName();
            String emailAddress = signupUserRequestPojo.getEmailAddress();
            String firstName = signupUserRequestPojo.getFirstName();
            String lastName = signupUserRequestPojo.getLastName();
            String password = PasswordCryptographyProvider.encrypt(signupUserRequestPojo.getPassword())[1];
            String country = signupUserRequestPojo.getCountry();
            String aboutMe = signupUserRequestPojo.getAboutMe();
            String dob = signupUserRequestPojo.getDob();
            String contactNumber = signupUserRequestPojo.getContactNumber();

            users = userDao.findByUserName(userName);
            if (users == null) {
                    throw new SignUpRestrictedException("SGR-001", "Try any other Username, this Username has already been taken");
            }
            users = userDao.findByEmailAddress(emailAddress);
            if (users == null) {
                throw new SignUpRestrictedException("SGR-002", "This user has already been registered, try with any other emailId");
            }
            signupUserRequest = new SignupUserRequest(firstName,lastName,userName,emailAddress,
                    password,country, aboutMe, dob,contactNumber);
            userDao.save(signupUserRequest);
            return new ApiResponse(HttpStatus.CREATED,"USER SUCCESSFULLY REGISTERED", signupUserRequest.getUuid());



        }
        catch(Exception e){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,"INTERNAL SERVER ERROR",signupUserRequest.getUuid());
        }
    }

    public ApiResponse signinUser(){
        return null;
    }

    public ApiResponse getUserProfile(Principal principal, String userId) {
        try {
            SignupUserRequest signupUserRequest = userDao.findByUuid(userId);
            if (signupUserRequest == null) {
                throw new UserNotFoundException("USR-001", "User with entered uuid does not exist");
            }
            else{
                Map<String, String> map = new HashMap<>();
                map.put("first_name", signupUserRequest.getFirstName());
                map.put("last_name",signupUserRequest.getLastName());
                map.put("user_name",signupUserRequest.getUserName());
                map.put("email_address",signupUserRequest.getEmailAddress());
                map.put("country",signupUserRequest.getCountry());
                map.put("aboutMe",signupUserRequest.getAboutMe());
                map.put("dob",signupUserRequest.getDob());
                map.put("contact_number",signupUserRequest.getContact_number());
                return new ApiResponse(HttpStatus.OK,"", map);
            }
        } catch (Exception ex) {
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,"INTERNAL_SERVER_ERROR", "");
        }

    }
}
