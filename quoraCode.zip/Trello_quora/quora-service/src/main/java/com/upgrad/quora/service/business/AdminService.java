package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.SignupUserRequest;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    @Autowired
    private UserDao userDao;

    public ApiResponse deleteUser(String userId){
        SignupUserRequest signupUserRequest = userDao.findByUuid(userId);
        signupUserRequest.setDeleted(true);
        userDao.save(signupUserRequest);
        return new ApiResponse(HttpStatus.OK, "USER SUCCESSFULLY DELETED",signupUserRequest.getUuid());
    }
}
