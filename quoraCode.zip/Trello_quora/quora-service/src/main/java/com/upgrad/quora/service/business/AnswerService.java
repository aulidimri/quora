package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.AnswerDao;
import com.upgrad.quora.service.dao.QuestionDao;
import com.upgrad.quora.service.entity.AnswerRequest;
import com.upgrad.quora.service.entity.QuestionRequest;
import com.upgrad.quora.service.exception.AnswerNotFoundException;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import com.upgrad.quora.service.pojo.AnswerRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerService {

    @Autowired
    private AnswerDao answerDao;

    @Autowired
    private QuestionDao questionDao;

    public ApiResponse createAnswer(AnswerRequestPojo answerRequestPojo, String questionId){
        QuestionRequest questionRequest = questionDao.findByUuid(questionId);
        try {
            if (questionRequest == null) {
                throw new InvalidQuestionException("QUES-001", "The question entered is invalid");
            }
            else{
                String answer = answerRequestPojo.getAnswer();
                String userId = answerRequestPojo.getUserId();
                AnswerRequest answerRequest = new AnswerRequest(answer, userId,questionId);
                answerDao.save(answerRequest);
                return new ApiResponse(HttpStatus.CREATED,"Answer created successfully",answerRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,"INTERNAL_SERVER_ERROR","");
        }
    }

    public ApiResponse editAnswerContent(String answerId, AnswerRequestPojo answerRequestPojo){
        AnswerRequest answerRequest = answerDao.findByUuid(answerId);
        try {
            if (answerRequest == null) {
                throw new AnswerNotFoundException("ANS-001","Entered answer uuid does not exist");
            }
            else{
                answerRequest.setAnswer(answerRequestPojo.getAnswer());
                answerDao.save(answerRequest);
                return new ApiResponse(HttpStatus.OK, "Answer changed successfully",answerRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",answerRequest.getUuid());

        }
    }

    public ApiResponse deleteAnswer(String questionId){
        AnswerRequest answerRequest = answerDao.findByUuid(questionId);
        try {
            if (answerRequest == null) {
                throw new InvalidQuestionException("ANS-001","Entered answer uuid does not exist'");
            }
            else{
                answerRequest.setDeleted(true);
                answerDao.save(answerRequest);
                return new ApiResponse(HttpStatus.OK, "Answer deleted successfully",answerRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",answerRequest.getUuid());

        }
    }

    public ApiResponse getAllAnswersToQuestion(String questionId){
        try {
            List<AnswerRequest> answerRequests = answerDao.findByQuestionId(questionId);
            if (answerRequests.isEmpty()) {
                throw new UserNotFoundException("QUES-001", "The question with entered uuid whose details are to be seen does not exist");
            } else {
                return new ApiResponse(HttpStatus.OK, "Fetched the answers successfully", answerRequests);
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR","");
        }
    }
}
