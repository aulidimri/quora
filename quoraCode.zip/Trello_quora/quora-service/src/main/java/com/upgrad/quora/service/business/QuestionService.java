package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.QuestionDao;
import com.upgrad.quora.service.entity.QuestionRequest;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import com.upgrad.quora.service.pojo.QuestionRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

    @Autowired
    private QuestionDao questionDao;
    public ApiResponse createQuestion(QuestionRequestPojo questionRequestPojo){
        String question = questionRequestPojo.getQuestion();
        String userId = questionRequestPojo.getUserId();
        QuestionRequest questionRequest = new QuestionRequest(question, userId);
        questionDao.save(questionRequest);
        return new ApiResponse(HttpStatus.CREATED,"Question created successfully",questionRequest.getUuid());
    }

    public ApiResponse getQuestions(){
        List<QuestionRequest> questions = questionDao.findAll();
        return new ApiResponse(HttpStatus.OK,"Questions fetched successfully",questions);
    }

    public ApiResponse editQuestionContent(String questionId, QuestionRequestPojo questionRequestPojo){
        String uuid = questionRequestPojo.getUuid();
        QuestionRequest questionRequest = questionDao.findByUuid(uuid);
        try {
            if (questionRequest == null) {
                throw new InvalidQuestionException("QUES-001","Entered question uuid does not exist");
            }
            else{
                questionRequest.setQuestion(questionRequestPojo.getQuestion());
                questionDao.save(questionRequest);
                return new ApiResponse(HttpStatus.OK, "Questions changed successfully",questionRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",questionRequest.getUuid());

        }
    }

    public ApiResponse deleteQuestion(String questionId){
        QuestionRequest questionRequest = questionDao.findByUuid(questionId);
        try {
            if (questionRequest == null) {
                throw new InvalidQuestionException("QUES-001","Entered question uuid does not exist");
            }
            else{
                questionRequest.setDeleted(true);
                questionDao.save(questionRequest);
                return new ApiResponse(HttpStatus.OK, "Questions deleted successfully",questionRequest.getUuid());
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR",questionRequest.getUuid());

        }
    }

    public ApiResponse getAllQuestionsByUser(String userId){
        try {
            List<QuestionRequest> questionRequests = questionDao.findByUserId(userId);
            if (questionRequests.isEmpty()) {
                throw new UserNotFoundException("USR-001", "User with entered uuid whose question details are to be seen does not exist");
            } else {
                return new ApiResponse(HttpStatus.OK, "Fetched the questions successfully", questionRequests);
            }
        }
        catch(Exception ex){
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL SERVER ERROR","");
        }
    }
}
