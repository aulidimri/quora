package com.upgrad.quora.service.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;

public class QuestionRequest {

    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "uuid", columnDefinition = "BINARY(16)")
    String uuid;

    @Column
    private String question;

    @Column
    private String userId;

    @Column
    private Boolean isDeleted;

    public String getUuid() {

        return uuid;
    }

    public QuestionRequest() {
        super();
    }

    public QuestionRequest(String question, String userId) {
        this.question = question;
        this.userId = userId;
        this.isDeleted = false;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public Boolean getDeleted() {
        return isDeleted;
    }

    public void setDeleted(Boolean deleted) {
        isDeleted = deleted;
    }
}
