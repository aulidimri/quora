package com.upgrad.quora.service.pojo;

public class AnswerRequestPojo {
    private String userId;
    private String answer;
    public AnswerRequestPojo(String answer, String userId, String questionId) {
        this.answer = answer;
        this.userId = userId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }


}
