package com.upgrad.quora.service.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import java.util.UUID;

public class AnswerRequest {

    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "uuid", columnDefinition = "BINARY(16)")
    UUID uuid;

    @Column
    private String questionId;

    @Column
    private String answer;

    @Column
    private String userId;

    @Column
    private Boolean isDeleted;

    public UUID getUuid() {
        return uuid;
    }

    public AnswerRequest() {
        super();
    }

    public AnswerRequest(String answer, String userId, String questionId) {
        this.answer = answer;
        this.questionId = questionId;
        this.userId = userId;
        this.isDeleted = false;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Boolean getDeleted() {
        return isDeleted;
    }

    public void setDeleted(Boolean deleted) {
        isDeleted = deleted;
    }
}
