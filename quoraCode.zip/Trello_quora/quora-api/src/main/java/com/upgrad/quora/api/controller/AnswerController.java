package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.AnswerService;
import com.upgrad.quora.service.pojo.AnswerRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class AnswerController {

    @Autowired
    private AnswerService answerService;
    @RequestMapping(method = RequestMethod.POST, value = "/question/{questionId}/answer/create")
    public ApiResponse createAnswer(@PathVariable String questionId, @RequestBody @Valid AnswerRequestPojo answerRequestPojo){
        return answerService.createAnswer(answerRequestPojo, questionId);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/answer/edit/{answerId}")
    public ApiResponse editAnswerContent(@PathVariable String answerId, @RequestBody @Valid AnswerRequestPojo answerRequestPojo){
        return answerService.editAnswerContent(answerId, answerRequestPojo);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/answer/delete/{answerId}")
    public ApiResponse deleteAnswer(@PathVariable String answerId){
        return answerService.deleteAnswer(answerId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "answer/all/{questionId}")
    public ApiResponse getAllAnswersToQuestion(@PathVariable String questionId){
        return answerService.getAllAnswersToQuestion(questionId);
    }
}
