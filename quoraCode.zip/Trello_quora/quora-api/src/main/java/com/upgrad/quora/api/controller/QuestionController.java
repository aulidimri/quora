package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.QuestionService;
import com.upgrad.quora.service.pojo.QuestionRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;

@RestController
public class QuestionController {

    @Autowired
    QuestionService questionService;

    @RequestMapping(method = RequestMethod.POST, value ="/question/create")
    public ApiResponse createQuestion(Principal principal, @RequestBody @Valid QuestionRequestPojo questionRequestPojo){
        return questionService.createQuestion(questionRequestPojo);
    }

    @RequestMapping(method = RequestMethod.GET, value ="/question/all")
    public ApiResponse getAllQuestions(Principal principal){
        return questionService.getQuestions();
    }

    @RequestMapping(method = RequestMethod.PUT, value ="/question/edit/{questionId}")
    public ApiResponse editQuestionContent(@PathVariable String questionId, @RequestBody @Valid QuestionRequestPojo questionRequestPojo){
        return questionService.editQuestionContent(questionId, questionRequestPojo);
    }


    @RequestMapping(method = RequestMethod.DELETE, value ="/question/delete/{questionId}")
    public ApiResponse deleteQuestion(@PathVariable String questionId){
        return questionService.deleteQuestion(questionId);
    }

    @RequestMapping(method = RequestMethod.GET, value ="question/all/{userId}")
    public ApiResponse getAllQuestionsByUser(@PathVariable String userId){
        return questionService.getAllQuestionsByUser(userId);
    }


}
