package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
public class CommonController {
    @Autowired
    private UserService userService;

    @RequestMapping(method = RequestMethod.GET, value = "/userprofile/{userId}")
    public void userProfile(Principal principal, @PathVariable String userId){
        userService.getUserProfile(principal,userId);

    }
}
