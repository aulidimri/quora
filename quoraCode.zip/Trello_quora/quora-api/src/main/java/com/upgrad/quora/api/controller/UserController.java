package com.upgrad.quora.api.controller;

import com.upgrad.quora.service.business.UserService;
import com.upgrad.quora.service.pojo.SignupUserRequestPojo;
import com.upgrad.quora.service.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(method= RequestMethod.POST, value = "/user/signup")
    public ApiResponse signup(@RequestBody @Valid SignupUserRequestPojo signupUserRequestPojo){
        return userService.registerNewUser(signupUserRequestPojo);
    }

    @RequestMapping(method= RequestMethod.POST, value = "/user/signin")
    public ApiResponse signin(){
        return userService.signinUser();
    }

    @RequestMapping(method= RequestMethod.POST, value = "/user/signout")
    public void singout(){

    }




}
